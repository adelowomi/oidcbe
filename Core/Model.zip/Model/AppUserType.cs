﻿using System;
namespace Core.Model
{
    public class AppUserType : BaseEntity
    {
        public string Name { get; set; }
    }
}
