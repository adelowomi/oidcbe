﻿using System;
using Microsoft.AspNetCore.Identity;

namespace Core.Model
{
    public class UserToken : IdentityUserToken<int>
    {
      
    }
}
