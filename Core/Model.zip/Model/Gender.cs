﻿using System;
namespace Core.Model
{
    public class Gender : BaseEntity
    {
        public string Name { get; set; }
    }
}
