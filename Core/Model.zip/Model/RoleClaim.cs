﻿using System;
using Microsoft.AspNetCore.Identity;

namespace Core.Model
{
    public class RoleClaim : IdentityRoleClaim<int>
    {
        
    }
}
