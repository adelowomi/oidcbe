﻿using System;
using System.Collections.Generic;

namespace Core.Model
{
    public class AppUserDetail : BaseEntity
    {
        public string ProfilePhoto { get; set; }
    }
}
