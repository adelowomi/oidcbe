﻿using System;
namespace Core.Model
{
    public class PlotType : BaseEntity
    {
        public string Name { get; set; }
    }
}
